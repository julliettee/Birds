﻿namespace BirdsSpace {
    public interface IFlyable {
        void Fly();
    }
}