﻿namespace BirdsSpace {
    public interface ISwimable {
        void Swim();
    }
}